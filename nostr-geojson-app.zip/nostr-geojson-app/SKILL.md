---
name: nostr-geojson-app
description: This skill should be used when building Earthly, a Nostr-based GeoJSON collaborative mapping application. Use when working with GeoJSON events (kinds 31991, 30406, 30078), implementing NDK custom event classes, developing the GeoEditor, adding NIP-inspired features (threading, moderation, commenting), validating events, generating seed data, integrating MapLibre with Nostr, or working with the Go relay (Khatru). This skill serves as an evolving source of truth that updates as the spec and architecture extend.
---

# Earthly - Nostr GeoJSON Application Skill

## Project Overview

**Earthly** is a Nostr-based GeoJSON collaborative mapping application. Users can publish, discover, and edit geographic datasets over a decentralized Nostr relay network.

**Architecture:**
```
Frontend (React/Bun) ←→ Nostr Relay (Go/Khatru) ←→ Other Nostr Clients
     ↓
MapLibre GL Editor
     ↓
GeoJSON Events (kind 31991)
Collections (kind 30406)
```

**Tech Stack:**
- **Runtime:** Bun (not Node.js)
- **Frontend:** React 19 + TypeScript
- **Backend:** Bun.serve() + Go relay (Khatru)
- **Mapping:** MapLibre GL with GeoJSON
- **State Management:** Zustand
- **Nostr Integration:** NDK (Nostr Dev Kit)
- **Styling:** Tailwind CSS v4 + Radix UI
- **Build:** Custom build.ts with bun-plugin-tailwind
- **Environment:** Zod validation for config

This skill follows a **self-updating pattern** where the spec and implementation evolve together, inspired by existing NIPs (threading, moderation, commenting) but adapted for geospatial data.

## Development Commands

```bash
# Development
bun dev                    # Start dev server with HMR (runs ./scripts/dev-clean.sh)
bun relay                  # Start Go relay on port 3334
bun relay:reset            # Reset relay database and restart
bun relay:kill             # Kill relay process
bun run seed              # Generate seed data with Faker

# Building & Deployment
bun run build             # Frontend build (dev mode)
bun run build:production  # Production build with minification
bun start                 # Run production server (requires build first)

# Testing
bun test                  # Run tests with Bun's test runner
```

## Core Capabilities

### 1. Understanding the GeoJSON Event Specification

The spec defines three primary event kinds for publishing geospatial data over Nostr:

**Kind 31991 - GeoJSON Data Event**
- Content: RFC 7946 FeatureCollection (JSON.stringify, no base64)
- Mandatory tags: `d` (UUID), `bbox` (west,south,east,north)
- Recommended tags: `g` (geohash), `checksum`, `size`, `v` (version), `crs`, `r` (relay), `t` (hashtags)
- Supports external blob references for large datasets (HTTPS, IPFS, Arweave)

**Kind 30406 - GeoJSON Collection Event**
- Content: JSON metadata (name, description, picture, license, tags)
- References multiple data events via `a` tags (coordinates: `kind:pubkey:d`)
- Aggregates bbox and geohash from member datasets

**Kind 30078 - Encrypted GeoJSON**
- Private datasets with encrypted content
- Mirrors tags from plaintext stub (except sensitive data)

For complete specification details, see `references/SPEC.md`.

### 2. Implementing NDK Custom Event Classes

Follow the **NDK Event Class Registration pattern** for all GeoJSON event types. This pattern provides:

- Type-safe accessors for tags and content
- Automatic metadata computation (bbox, geohash, checksum)
- Publishing workflows (new, update, delete)
- Integration with @nostr-dev-kit/react hooks

**Quick Start Pattern:**

```typescript
import { NDKEvent, registerEventClass, type NDKSigner } from "@nostr-dev-kit/ndk";

export class NDKGeoThreadEvent extends NDKEvent {
  static kinds = [31992]; // New kind for geo threads

  static from(event: NDKEvent): NDKGeoThreadEvent {
    const wrapped = new NDKGeoThreadEvent(event.ndk, event);
    wrapped.kind = event.kind ?? NDKGeoThreadEvent.kinds[0];
    return wrapped;
  }

  // Typed content accessor
  get parsedContent(): ThreadContent {
    if (!this.content) return DEFAULT_CONTENT;
    try {
      return JSON.parse(this.content) as ThreadContent;
    } catch {
      return DEFAULT_CONTENT;
    }
  }

  set parsedContent(value: ThreadContent) {
    this.content = JSON.stringify(value);
  }

  // Tag accessors
  get threadRoot(): string | undefined {
    return this.tagValue("e")?.split(":")[0]; // NIP-10 style
  }

  // Publishing methods
  async publishNew(signer?: NDKSigner): Promise<NDKGeoThreadEvent> {
    await this.prepareForPublish(signer);
    await this.publish();
    return this;
  }

  private async prepareForPublish(signer?: NDKSigner): Promise<void> {
    this.kind = NDKGeoThreadEvent.kinds[0];
    this.ensureIdentifier();
    await this.sign(signer);
  }
}

registerEventClass(NDKGeoThreadEvent);
```

**Complete pattern documentation:** `references/ndk-event-class-pattern.md`
**Template for new event classes:** `assets/event-class-template.ts`

### 3. Core Architecture Components

**1. GeoEditor (`src/features/geo-editor/core/GeoEditor.ts`)**
- Main editing engine built on MapLibre GL
- Manages drawing modes: point, linestring, polygon
- Handles selection, snapping, undo/redo, transforms
- Organized into focused managers:
  - **SelectionManager** - Feature selection and highlighting
  - **HistoryManager** - Undo/redo operations
  - **SnapManager** - Vertex snapping during drawing
  - **TransformManager** - Move, rotate, scale operations

**2. Editor State (`src/features/geo-editor/store.ts`)**
- Zustand store with 50+ actions
- Manages features, mode, selection, datasets, publishing state
- Syncs between GeoEditor instance and React UI
- Single source of truth for editor state

**3. GeoEditorView (`src/features/geo-editor/GeoEditorView.tsx`)**
- ~2000 line orchestration component (intentionally large)
- Coordinates map, toolbar, panels, and editor state
- Handles dataset loading/publishing workflow
- Manages blob reference resolution
- Mobile-first responsive UI with collapsible panels

**4. Nostr Event Classes (`src/lib/ndk/`)**
- **NDKGeoEvent** (kind 31991) - GeoJSON datasets with typed accessors
- **NDKGeoCollectionEvent** (kind 30406) - Dataset collections
- Custom NDK event wrappers with GeoJSON-specific methods
- Auto-compute metadata (bbox, geohash, checksum)

**5. Go Relay (`relay/main.go`)**
- Khatru-based Nostr relay
- SQLite for event storage
- Bluge for full-text search (NIP-50)
- Supports Blossom blob storage for large GeoJSON

**6. Build System (`build.ts`)**
- Custom Bun build using `bun-plugin-tailwind`
- Environment variable injection via `define` (bundler replaces `process.env.*`)
- Validates env with Zod schema before build (`src/config/env.schema.ts`)
- Processes all HTML entrypoints in `src/`

**7. External Integrations**
- **ContextVM (MCP):** `src/ctxcn/EarthlyGeoServerClient.ts` - MCP client for geo services
  - `SearchLocation(query, limit)` - Place name search
  - `ReverseLookup(lat, lon, zoom)` - Reverse geocoding
  - Uses Nostr transport for communication
- **MapLibre Ecosystem:**
  - Protomaps basemaps for tile rendering
  - PMTiles for local tile serving
  - OpenFreeMap styles (Liberty style default)

### 4. Data Flow & Publishing Workflows

#### Publishing a Dataset (Full Flow)

1. User draws features in GeoEditor (`src/features/geo-editor/core/GeoEditor.ts`)
2. Features stored in EditorState.features (`src/features/geo-editor/store.ts`)
3. Click "Publish New" in UI
4. `buildCollectionFromEditor()` creates FeatureCollection from editor features
5. Create NDKGeoEvent, set content and blob references (if needed for large datasets)
6. `event.publishNew()` signs and publishes to relay
7. Relay stores in SQLite + indexes in Bluge (`relay/main.go`)

#### Loading a Dataset for Editing (Full Flow)

1. User selects dataset from GeoDatasetsPanel
2. `loadDatasetForEditing(event)` called in GeoEditorView
3. `ensureResolvedFeatureCollection()` fetches blob references if present
4. `convertGeoEventsToEditorFeatures()` converts GeoJSON to editor format
5. `editor.setFeatures(features)` updates MapLibre layers
6. Editor state synchronized, user can now edit

### 5. Common Code Examples

#### Creating a GeoJSON Data Event

```typescript
import { NDKGeoEvent } from "./lib/ndk/NDKGeoEvent";
import { useNDK } from "@nostr-dev-kit/react";

function CreateDataset() {
  const { ndk, signer } = useNDK();

  const publishDataset = async (featureCollection: FeatureCollection) => {
    const event = new NDKGeoEvent(ndk);
    event.featureCollection = featureCollection;
    event.hashtags = ["parks", "vienna"];
    event.updateDerivedMetadata(); // Computes bbox, geohash, size
    await event.updateChecksum();
    await event.publishNew(signer);
  };

  return <div>...</div>;
}
```

#### Querying Events by Location

```typescript
import { useSubscribe } from "@nostr-dev-kit/react";

function MapView({ geohash }: { geohash: string }) {
  const { events } = useSubscribe({
    filters: [
      {
        kinds: [31991],
        "#g": [geohash], // Query by geohash for proximity
      },
    ],
  });

  const geoEvents = events as NDKGeoEvent[];

  return (
    <Map>
      {geoEvents.map(event => (
        <GeoJSONLayer key={event.id} data={event.featureCollection} />
      ))}
    </Map>
  );
}
```

#### Handling External Blobs

```typescript
async function fetchBlobFeatures(event: NDKGeoEvent): Promise<FeatureCollection> {
  const blobs = event.blobReferences;
  const collection = event.featureCollection;

  for (const blob of blobs) {
    if (blob.scope === "feature" && blob.featureId) {
      // Fetch remote feature
      const response = await fetch(blob.url);
      const remoteFeatures = await response.json();

      // Verify checksum if provided
      if (blob.sha256) {
        const text = await response.text();
        const checksum = await computeChecksum(text);
        if (checksum !== blob.sha256) {
          console.warn("Checksum mismatch for blob:", blob.url);
          continue;
        }
      }

      // Replace placeholder
      const placeholderIndex = collection.features.findIndex(
        f => f.id === blob.featureId
      );
      if (placeholderIndex >= 0) {
        collection.features.splice(placeholderIndex, 1, ...remoteFeatures.features);
      }
    }
  }

  return collection;
}
```

### 6. Extending the Spec with NIP-Inspired Features

When adding new functionality inspired by existing NIPs, follow this pattern:

1. **Research the source NIP** (e.g., NIP-10 for threading, NIP-72 for moderation)
2. **Adapt tags and structure** for GeoJSON context
3. **Update `references/SPEC.md`** with the new patterns
4. **Implement NDK event class** following the registration pattern
5. **Generate seed data** for testing with `scripts/generate-seed-data.ts`
6. **Validate events** with `scripts/validate-geo-event.ts`

**Example: Adding NIP-10 inspired threading for GeoJSON discussions**

```typescript
// New kind 31992 for geo-threads
export class NDKGeoThreadEvent extends NDKEvent {
  static kinds = [31992];

  // NIP-10 style thread structure
  get rootEvent(): string | undefined {
    const rootTag = this.tags.find(t => t[0] === "e" && t[3] === "root");
    return rootTag?.[1];
  }

  get replyTo(): string | undefined {
    const replyTag = this.tags.find(t => t[0] === "e" && t[3] === "reply");
    return replyTag?.[1];
  }

  // Reference to GeoJSON feature being discussed
  get featureRef(): string | undefined {
    return this.tagValue("feature");
  }

  createReply(content: string, parentEventId: string, rootEventId?: string): NDKGeoThreadEvent {
    const reply = new NDKGeoThreadEvent(this.ndk);
    reply.content = content;
    reply.tags.push(["e", rootEventId ?? parentEventId, "", "root"]);
    if (rootEventId) {
      reply.tags.push(["e", parentEventId, "", "reply"]);
    }
    reply.tags.push(["p", this.pubkey]); // Mention parent author
    return reply;
  }
}
```

**Example: Adding NIP-72 inspired moderation**

```typescript
// Moderation tags for geo-content
export interface GeoModerationReport {
  eventId: string; // GeoJSON event being reported
  reason: "malicious-data" | "copyright" | "spam" | "inappropriate" | "other";
  details?: string;
}

export class NDKGeoModerationEvent extends NDKEvent {
  static kinds = [1984]; // NIP-72 report kind

  get reportedEvent(): string | undefined {
    const eTag = this.tags.find(t => t[0] === "e");
    return eTag?.[1];
  }

  get reportType(): string | undefined {
    return this.tagValue("report");
  }

  static createReport(
    ndk: NDK,
    report: GeoModerationReport
  ): NDKGeoModerationEvent {
    const event = new NDKGeoModerationEvent(ndk);
    event.kind = 1984;
    event.tags.push(["e", report.eventId]);
    event.tags.push(["report", report.reason]);
    event.content = report.details ?? "";
    return event;
  }
}
```

### 7. Working with Real-World Data

The project includes comprehensive tooling for working with public GeoJSON datasets. See `references/public-datasets.md` for a curated list of sources.

**Fetch Remote GeoJSON:**

```bash
# Option A: Fetch from static URL
bun .claude/skills/nostr-geojson-app/scripts/fetch-geojson.ts \
  --url="https://raw.githubusercontent.com/datasets/geo-countries/main/data/countries.geojson"

# Custom output path
bun scripts/fetch-geojson.ts \
  --url="https://example.com/data.geojson" \
  --output="./my-data.geojson"

# Option B: Fetch from Nominatim (on-demand boundaries)
bun .claude/skills/nostr-geojson-app/scripts/get-bounds.ts "Berlin"

# Save boundary to file for seeding/tests
bun scripts/get-bounds.ts "Vienna, Austria" --output="./vienna.geojson"

# Get multiple results
bun scripts/get-bounds.ts "Springfield" --limit=3
```

**Analyze File Size:**

```bash
# Check if data should be inline or blob reference
bun .claude/skills/nostr-geojson-app/scripts/json-size.ts ./data.geojson

# Returns:
# - Size in bytes/KB/MB
# - Feature count
# - Recommendation: inline | simplify | blob
# - Exit code: 0 (inline OK), 1 (simplify), 2 (blob required)
```

**Simplify Large Datasets:**

```bash
# Reduce size with turf.simplify
bun .claude/skills/nostr-geojson-app/scripts/simplify-geojson.ts \
  --input="./world.geojson" \
  --tolerance=0.01

# Higher tolerance = more simplification
bun scripts/simplify-geojson.ts \
  --input="./counties.geojson" \
  --tolerance=0.05 \
  --output="./counties-simple.geojson"
```

**Decision Flow for Real-World Data:**

1. **Fetch:** Download GeoJSON
   - Static datasets: `fetch-geojson.ts --url=<url>`
   - On-demand boundaries: `get-bounds.ts "Place Name"`
2. **Analyze:** Check size with `json-size.ts`
3. **Decide:**
   - **< 1MB**: Use inline in event content
   - **800KB - 1.2MB**: Simplify with `simplify-geojson.ts`
   - **> 1MB**: Use blob reference or split into multiple events
4. **Publish:** Create NDKGeoEvent with appropriate strategy

**Public Dataset Sources:**

See `references/public-datasets.md` for curated sources including:
- **Nominatim (OpenStreetMap)**: On-demand administrative boundaries for any place
- World countries (Natural Earth, georgique/world-geojson)
- US states and counties (eric.clst.org)
- Government data (data.gov catalog)
- Historical boundaries (historical-basemaps)
- Live APIs (OGC API Features)

### 8. Validation and Testing

**Validate Events Against Spec:**

```bash
# Validate a single event
bun scripts/validate-geo-event.ts ./my-event.json

# Validate event from string
bun scripts/validate-geo-event.ts '{"kind":31991,...}'
```

**Generate Seed Data for Testing:**

```bash
# Generate 5 data events + 1 collection
bun scripts/generate-seed-data.ts --count=5 --output=./seed.json

# Import and use programmatically
import { generateSeedData } from "./scripts/generate-seed-data.ts";
const events = await generateSeedData({ count: 10 });
```

**Seed with Real-World Data:**

The project has a comprehensive seeding suite at `scripts/` including:
- `scripts/seed.ts` - Main seeding orchestrator
- `scripts/gen_geo_events.ts` - Generate GeoJSON data events
- `scripts/gen_collections.ts` - Generate collection events
- `scripts/gen_user.ts` - Generate user/keypair

Enhance with real data:
```typescript
// Fetch and publish real dataset
import { fetchGeoJSON } from "./.claude/skills/nostr-geojson-app/scripts/fetch-geojson.ts";
import { analyzeGeoJSONSize } from "./.claude/skills/nostr-geojson-app/scripts/json-size.ts";

const { outputPath } = await fetchGeoJSON({
  url: "https://raw.githubusercontent.com/datasets/geo-countries/main/data/countries.geojson"
});

const analysis = await analyzeGeoJSONSize(outputPath);

if (analysis.recommendation === "inline") {
  // Create event with inline content
  const data = JSON.parse(await Bun.file(outputPath).text());
  const event = new NDKGeoEvent(ndk);
  event.featureCollection = data;
  event.hashtags = ["countries", "world"];
  event.tags.push(["source", "https://github.com/datasets/geo-countries"]);
  event.tags.push(["license", "PDDL"]);
  await event.publishNew(signer);
}
```

### 9. MapLibre Integration Patterns

**Rendering GeoJSON Events on Map:**

```typescript
import { Map, Source, Layer } from "react-map-gl/maplibre";
import type { NDKGeoEvent } from "./lib/ndk/NDKGeoEvent";

function GeoEventLayer({ event }: { event: NDKGeoEvent }) {
  return (
    <Source
      id={event.id}
      type="geojson"
      data={event.featureCollection}
    >
      <Layer
        id={`${event.id}-fill`}
        type="fill"
        paint={{
          "fill-color": "#3b82f6",
          "fill-opacity": 0.4,
        }}
      />
      <Layer
        id={`${event.id}-line`}
        type="line"
        paint={{
          "line-color": "#1d4ed8",
          "line-width": 2,
        }}
      />
    </Source>
  );
}
```

**Using the Custom Geo Editor:**

Refer to `src/features/geo-editor/` for drawing and editing features. The editor provides tools for creating points, lines, and polygons that can be published as GeoJSON events.

### 10. Self-Updating Skill Pattern

This skill is designed to evolve alongside the spec. When extending functionality:

1. **Reflect changes in `references/SPEC.md`** - Document new event kinds, tags, and behaviors
2. **Update NDK event classes** - Implement new functionality following the registration pattern
3. **Add validation rules** - Extend `scripts/validate-geo-event.ts` for new event types
4. **Generate test data** - Update `scripts/generate-seed-data.ts` to include new patterns
5. **Document in SKILL.md** - Add new workflows and examples to this file

**The skill serves as a "checkpoint" where progress is "cashed in"** - all architectural decisions, patterns, and extensions are documented here for future reference.

## Resources

### references/
- **SPEC.md** - Complete GeoJSON event specification (kinds 31991, 30406, 30078)
- **ndk-event-class-pattern.md** - Comprehensive guide to NDK custom event class pattern with real examples
- **public-datasets.md** - Curated public GeoJSON datasets with size estimates, licenses, and usage recommendations

### scripts/
- **validate-geo-event.ts** - Validate GeoJSON events against the spec
- **generate-seed-data.ts** - Generate compliant test data for development
- **fetch-geojson.ts** - Fetch remote GeoJSON and analyze size
- **get-bounds.ts** - Fetch administrative boundaries from Nominatim API (OpenStreetMap)
- **json-size.ts** - Analyze GeoJSON file size and get inline/blob recommendation
- **simplify-geojson.ts** - Simplify geometry to reduce file size using Turf.js

### assets/
- **event-class-template.ts** - Boilerplate template for creating new NDK event classes

## Quick Reference

**Create and publish a dataset:**
```typescript
const event = new NDKGeoEvent(ndk);
event.featureCollection = myGeoJSON;
event.updateDerivedMetadata();
await event.updateChecksum();
await event.publishNew(signer);
```

**Query by location:**
```typescript
const { events } = useSubscribe({
  filters: [{ kinds: [31991], "#g": [geohash] }],
});
```

**Update existing dataset:**
```typescript
const updated = new NDKGeoEvent(ndk);
updated.featureCollection = newGeoJSON;
await updated.publishUpdate(previousEvent, signer);
```

**Delete dataset:**
```typescript
await NDKGeoEvent.deleteDataset(ndk, event, "Outdated data", signer);
```

**Validate event:**
```bash
bun scripts/validate-geo-event.ts event.json
```

**Generate seed data:**
```bash
bun scripts/generate-seed-data.ts --count=10
```

**Work with real-world datasets:**
```bash
# Fetch from static URL
bun .claude/skills/nostr-geojson-app/scripts/fetch-geojson.ts --url=<url>

# Fetch boundaries from Nominatim
bun .claude/skills/nostr-geojson-app/scripts/get-bounds.ts "Berlin" --output=./berlin.geojson

# Analyze and simplify
bun .claude/skills/nostr-geojson-app/scripts/json-size.ts ./data.geojson
bun .claude/skills/nostr-geojson-app/scripts/simplify-geojson.ts --input=./data.geojson --tolerance=0.01
```