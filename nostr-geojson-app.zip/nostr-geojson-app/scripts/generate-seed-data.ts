#!/usr/bin/env bun

/**
 * Generate seed GeoJSON events for testing
 * Usage: bun scripts/generate-seed-data.ts [--count=5] [--output=./seed-events.json]
 */

import type { FeatureCollection, Feature, Point, Polygon } from "geojson";
import * as turf from "@turf/turf";

interface SeedEventOptions {
  count?: number;
  output?: string;
  includeBlobs?: boolean;
}

function encodeGeohash(lat: number, lon: number, precision = 6): string {
  const base32 = "0123456789bcdefghjkmnpqrstuvwxyz";
  let geohash = "";
  let even = true;
  let latRange: [number, number] = [-90, 90];
  let lonRange: [number, number] = [-180, 180];

  while (geohash.length < precision) {
    let ch = 0;
    for (let bit = 0; bit < 5; bit++) {
      if (even) {
        const mid = (lonRange[0] + lonRange[1]) / 2;
        if (lon >= mid) {
          ch |= 1 << (4 - bit);
          lonRange[0] = mid;
        } else {
          lonRange[1] = mid;
        }
      } else {
        const mid = (latRange[0] + latRange[1]) / 2;
        if (lat >= mid) {
          ch |= 1 << (4 - bit);
          latRange[0] = mid;
        } else {
          latRange[1] = mid;
        }
      }
      even = !even;
    }
    geohash += base32[ch];
  }

  return geohash;
}

async function computeChecksum(content: string): Promise<string> {
  const encoder = new TextEncoder();
  const data = encoder.encode(content);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  return hashArray.map(byte => byte.toString(16).padStart(2, "0")).join("");
}

function generateRandomPoint(minLon: number, minLat: number, maxLon: number, maxLat: number): [number, number] {
  return [
    minLon + Math.random() * (maxLon - minLon),
    minLat + Math.random() * (maxLat - minLat),
  ];
}

async function generateGeoDataEvent(name: string, bbox: [number, number, number, number]) {
  const [west, south, east, north] = bbox;

  // Generate random points within bbox
  const features: Feature[] = [];
  const pointCount = 3 + Math.floor(Math.random() * 5);

  for (let i = 0; i < pointCount; i++) {
    const coords = generateRandomPoint(west, south, east, north);
    features.push({
      type: "Feature",
      id: `point-${i}`,
      geometry: {
        type: "Point",
        coordinates: coords,
      },
      properties: {
        name: `Point ${i + 1}`,
        category: ["landmark", "trailhead", "parking", "viewpoint"][Math.floor(Math.random() * 4)],
      },
    });
  }

  const collection: FeatureCollection = {
    type: "FeatureCollection",
    name,
    features,
  };

  const content = JSON.stringify(collection);
  const checksum = await computeChecksum(content);

  // Compute centroid and geohash
  const centroid = turf.centroid(collection);
  const [lon, lat] = centroid.geometry.coordinates;
  const geohash = encodeGeohash(lat, lon, 6);

  const datasetId = crypto.randomUUID();

  return {
    id: crypto.randomUUID(), // In real events this is computed from signature
    pubkey: "npub1examplepubkey" + Math.random().toString(36).substring(7),
    created_at: Math.floor(Date.now() / 1000),
    kind: 31991,
    content,
    tags: [
      ["d", datasetId],
      ["bbox", bbox.join(",")],
      ["g", geohash],
      ["crs", "EPSG:4326"],
      ["checksum", checksum],
      ["size", String(new TextEncoder().encode(content).length)],
      ["v", "1"],
      ["t", "test"],
      ["t", "seed"],
    ],
    sig: "placeholder-signature",
  };
}

async function generateGeoCollectionEvent(dataEvents: any[], name: string, description: string) {
  const metadata = {
    name,
    description,
    license: "CC-BY-4.0",
    tags: ["test", "seed"],
  };

  const content = JSON.stringify(metadata);
  const collectionId = crypto.randomUUID();

  // Combine bboxes
  let minLon = Infinity, minLat = Infinity, maxLon = -Infinity, maxLat = -Infinity;

  for (const event of dataEvents) {
    const bboxTag = event.tags.find((t: string[]) => t[0] === "bbox");
    if (bboxTag) {
      const [w, s, e, n] = bboxTag[1].split(",").map(Number);
      minLon = Math.min(minLon, w);
      minLat = Math.min(minLat, s);
      maxLon = Math.max(maxLon, e);
      maxLat = Math.max(maxLat, n);
    }
  }

  const bbox = [minLon, minLat, maxLon, maxLat];
  const centroid = [(minLon + maxLon) / 2, (minLat + maxLat) / 2];
  const geohash = encodeGeohash(centroid[1], centroid[0], 6);

  const tags: string[][] = [
    ["d", collectionId],
    ["bbox", bbox.join(",")],
    ["g", geohash],
    ["t", "test"],
    ["t", "seed"],
  ];

  // Add references to data events
  for (const event of dataEvents) {
    const dTag = event.tags.find((t: string[]) => t[0] === "d");
    if (dTag) {
      tags.push(["a", `31991:${event.pubkey}:${dTag[1]}`]);
    }
  }

  return {
    id: crypto.randomUUID(),
    pubkey: "npub1examplepubkey" + Math.random().toString(36).substring(7),
    created_at: Math.floor(Date.now() / 1000),
    kind: 30406,
    content,
    tags,
    sig: "placeholder-signature",
  };
}

async function generateSeedData(options: SeedEventOptions = {}) {
  const { count = 5, output = "./seed-events.json" } = options;

  console.log(`Generating ${count} GeoJSON data events...`);

  // Sample regions
  const regions = [
    { name: "Vienna Parks", bbox: [16.1, 48.1, 16.7, 48.4] as [number, number, number, number] },
    { name: "Berlin Landmarks", bbox: [13.1, 52.3, 13.7, 52.7] as [number, number, number, number] },
    { name: "Paris Monuments", bbox: [2.1, 48.7, 2.5, 49.0] as [number, number, number, number] },
    { name: "London Trails", bbox: [-0.5, 51.3, 0.3, 51.7] as [number, number, number, number] },
    { name: "Barcelona Points", bbox: [1.9, 41.2, 2.3, 41.5] as [number, number, number, number] },
  ];

  const dataEvents = [];

  for (let i = 0; i < Math.min(count, regions.length); i++) {
    const region = regions[i];
    const event = await generateGeoDataEvent(region.name, region.bbox);
    dataEvents.push(event);
  }

  console.log(`Generating collection event...`);

  const collectionEvent = await generateGeoCollectionEvent(
    dataEvents,
    "European Cities Test Dataset",
    "Seed data for testing GeoJSON Nostr events"
  );

  const allEvents = [...dataEvents, collectionEvent];

  console.log(`Writing ${allEvents.length} events to ${output}...`);

  await Bun.write(output, JSON.stringify(allEvents, null, 2));

  console.log("✅ Seed data generated successfully!");
  console.log(`   Data events: ${dataEvents.length}`);
  console.log(`   Collection events: 1`);
  console.log(`   Total: ${allEvents.length}`);

  return allEvents;
}

// CLI entry point
if (import.meta.main) {
  const args = process.argv.slice(2);
  const options: SeedEventOptions = {};

  for (const arg of args) {
    if (arg.startsWith("--count=")) {
      options.count = parseInt(arg.split("=")[1], 10);
    } else if (arg.startsWith("--output=")) {
      options.output = arg.split("=")[1];
    }
  }

  await generateSeedData(options);
}

export { generateSeedData, generateGeoDataEvent, generateGeoCollectionEvent };