#!/usr/bin/env bun

/**
 * Fetch GeoJSON from a remote URL and save to local file
 * Usage: bun scripts/fetch-geojson.ts --url=<url> [--output=<path>]
 */

interface FetchOptions {
  url: string;
  output?: string;
}

async function fetchGeoJSON(options: FetchOptions) {
  const { url, output } = options;

  console.log(`Fetching GeoJSON from: ${url}`);

  try {
    const response = await fetch(url);

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const contentType = response.headers.get("content-type");
    if (!contentType?.includes("json")) {
      console.warn(`Warning: Content-Type is ${contentType}, expected JSON`);
    }

    const data = await response.text();
    const size = new TextEncoder().encode(data).length;

    // Validate it's valid JSON
    try {
      const parsed = JSON.parse(data);
      if (parsed.type !== "FeatureCollection" && parsed.type !== "Feature") {
        console.warn(`Warning: GeoJSON type is ${parsed.type}, expected FeatureCollection or Feature`);
      }
    } catch (err) {
      throw new Error(`Invalid JSON: ${err}`);
    }

    // Determine output path
    const outputPath = output ?? `./${new URL(url).pathname.split("/").pop() ?? "data.geojson"}`;

    await Bun.write(outputPath, data);

    console.log(`✅ Fetched successfully!`);
    console.log(`   Size: ${(size / 1024).toFixed(2)} KB (${size} bytes)`);
    console.log(`   Saved to: ${outputPath}`);

    // Size recommendation
    const sizeMB = size / (1024 * 1024);
    if (sizeMB > 1) {
      console.log(`\n⚠️  Size > 1MB - Recommend using blob reference`);
    } else if (sizeMB > 0.8) {
      console.log(`\n⚠️  Size close to 1MB - Consider simplifying geometry`);
    } else {
      console.log(`\n✅ Size < 1MB - Safe to include inline in event`);
    }

    return { size, outputPath };
  } catch (err) {
    console.error(`❌ Error fetching GeoJSON: ${err}`);
    process.exit(1);
  }
}

// CLI entry point
if (import.meta.main) {
  const args = process.argv.slice(2);
  const options: FetchOptions = { url: "" };

  for (const arg of args) {
    if (arg.startsWith("--url=")) {
      options.url = arg.split("=")[1];
    } else if (arg.startsWith("--output=")) {
      options.output = arg.split("=")[1];
    }
  }

  if (!options.url) {
    console.error("Usage: bun fetch-geojson.ts --url=<url> [--output=<path>]");
    console.error("\nExamples:");
    console.error("  bun scripts/fetch-geojson.ts --url=https://example.com/countries.geojson");
    console.error("  bun scripts/fetch-geojson.ts --url=https://example.com/data.geojson --output=./my-data.geojson");
    process.exit(1);
  }

  await fetchGeoJSON(options);
}

export { fetchGeoJSON };