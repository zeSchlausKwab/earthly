#!/usr/bin/env bun

/**
 * Analyze GeoJSON file size and provide recommendations
 * Usage: bun scripts/json-size.ts <file-path>
 */

import type { FeatureCollection } from "geojson";

interface SizeAnalysis {
  bytes: number;
  kilobytes: number;
  megabytes: number;
  featureCount: number;
  recommendation: "inline" | "simplify" | "blob";
  notes: string[];
}

async function analyzeGeoJSONSize(filePath: string): Promise<SizeAnalysis> {
  const file = Bun.file(filePath);

  if (!(await file.exists())) {
    throw new Error(`File not found: ${filePath}`);
  }

  const text = await file.text();
  const bytes = new TextEncoder().encode(text).length;
  const kilobytes = bytes / 1024;
  const megabytes = bytes / (1024 * 1024);

  let featureCount = 0;
  let recommendation: "inline" | "simplify" | "blob" = "inline";
  const notes: string[] = [];

  // Parse to get feature count
  try {
    const geojson = JSON.parse(text) as FeatureCollection;
    if (geojson.type === "FeatureCollection") {
      featureCount = geojson.features.length;
      notes.push(`${featureCount} features in collection`);
    } else if (geojson.type === "Feature") {
      featureCount = 1;
      notes.push("Single Feature (not FeatureCollection)");
    }
  } catch (err) {
    notes.push(`Warning: Failed to parse GeoJSON - ${err}`);
  }

  // Determine recommendation
  if (megabytes > 1) {
    recommendation = "blob";
    notes.push("Size exceeds 1MB WebSocket limit");
    notes.push("Use blob reference (HTTPS/IPFS/Arweave)");
  } else if (megabytes > 0.8) {
    recommendation = "simplify";
    notes.push("Size approaching 1MB limit");
    notes.push("Consider simplifying geometry with turf.simplify()");
    notes.push("Or use blob reference for safety");
  } else {
    recommendation = "inline";
    notes.push("Safe to include inline in event content");
  }

  return {
    bytes,
    kilobytes,
    megabytes,
    featureCount,
    recommendation,
    notes,
  };
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} bytes`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

// CLI entry point
if (import.meta.main) {
  const filePath = process.argv[2];

  if (!filePath) {
    console.error("Usage: bun json-size.ts <file-path>");
    console.error("\nExample:");
    console.error("  bun scripts/json-size.ts ./data.geojson");
    process.exit(1);
  }

  try {
    const analysis = await analyzeGeoJSONSize(filePath);

    console.log(`\n📊 GeoJSON Size Analysis: ${filePath}`);
    console.log(`${"─".repeat(60)}`);
    console.log(`Size:          ${formatBytes(analysis.bytes)}`);
    console.log(`               ${analysis.kilobytes.toFixed(2)} KB`);
    console.log(`               ${analysis.megabytes.toFixed(4)} MB`);
    console.log(`Features:      ${analysis.featureCount}`);
    console.log(`${"─".repeat(60)}`);

    const icon =
      analysis.recommendation === "inline"
        ? "✅"
        : analysis.recommendation === "simplify"
          ? "⚠️ "
          : "❌";

    console.log(`${icon} Recommendation: ${analysis.recommendation.toUpperCase()}`);
    console.log();

    for (const note of analysis.notes) {
      console.log(`   • ${note}`);
    }

    console.log();

    // Exit code based on recommendation
    if (analysis.recommendation === "blob") {
      process.exit(2); // Blob required
    } else if (analysis.recommendation === "simplify") {
      process.exit(1); // Simplification recommended
    }
    process.exit(0); // OK for inline
  } catch (err) {
    console.error(`❌ Error: ${err}`);
    process.exit(1);
  }
}

export { analyzeGeoJSONSize };