#!/usr/bin/env bun

/**
 * Simplify GeoJSON geometry to reduce file size
 * Uses Turf.js simplify with tolerance parameter
 * Usage: bun scripts/simplify-geojson.ts --input=<file> --tolerance=<number> [--output=<file>]
 */

import * as turf from "@turf/turf";
import type { FeatureCollection, Feature } from "geojson";

interface SimplifyOptions {
  input: string;
  output?: string;
  tolerance: number;
  highQuality?: boolean;
}

async function simplifyGeoJSON(options: SimplifyOptions) {
  const { input, tolerance, highQuality = true } = options;
  const output = options.output ?? input.replace(".geojson", "-simplified.geojson");

  console.log(`Simplifying GeoJSON: ${input}`);
  console.log(`Tolerance: ${tolerance} (smaller = more detail)`);

  const file = Bun.file(input);
  if (!(await file.exists())) {
    throw new Error(`File not found: ${input}`);
  }

  const text = await file.text();
  const originalSize = new TextEncoder().encode(text).length;

  const geojson = JSON.parse(text) as FeatureCollection;

  if (geojson.type !== "FeatureCollection") {
    throw new Error("Only FeatureCollection is supported");
  }

  // Simplify each feature
  const simplified: FeatureCollection = {
    ...geojson,
    features: geojson.features.map((feature) => {
      try {
        return turf.simplify(feature, {
          tolerance,
          highQuality,
        }) as Feature;
      } catch (err) {
        console.warn(`Warning: Failed to simplify feature ${feature.id ?? "unknown"}: ${err}`);
        return feature; // Keep original if simplification fails
      }
    }),
  };

  const simplifiedText = JSON.stringify(simplified);
  const simplifiedSize = new TextEncoder().encode(simplifiedText).length;

  await Bun.write(output, simplifiedText);

  const reduction = ((originalSize - simplifiedSize) / originalSize) * 100;

  console.log(`\n✅ Simplification complete!`);
  console.log(`   Original:   ${(originalSize / 1024).toFixed(2)} KB`);
  console.log(`   Simplified: ${(simplifiedSize / 1024).toFixed(2)} KB`);
  console.log(`   Reduction:  ${reduction.toFixed(1)}%`);
  console.log(`   Saved to:   ${output}`);

  if (simplifiedSize > 1024 * 1024) {
    console.log(`\n⚠️  Still > 1MB after simplification`);
    console.log(`   Try higher tolerance (e.g., ${tolerance * 2}) or use blob reference`);
  } else {
    console.log(`\n✅ Size now < 1MB - safe for inline use`);
  }

  return { originalSize, simplifiedSize, reduction, output };
}

// CLI entry point
if (import.meta.main) {
  const args = process.argv.slice(2);
  const options: Partial<SimplifyOptions> = {};

  for (const arg of args) {
    if (arg.startsWith("--input=")) {
      options.input = arg.split("=")[1];
    } else if (arg.startsWith("--output=")) {
      options.output = arg.split("=")[1];
    } else if (arg.startsWith("--tolerance=")) {
      options.tolerance = parseFloat(arg.split("=")[1]);
    } else if (arg === "--high-quality") {
      options.highQuality = true;
    } else if (arg === "--fast") {
      options.highQuality = false;
    }
  }

  if (!options.input || options.tolerance === undefined) {
    console.error("Usage: bun simplify-geojson.ts --input=<file> --tolerance=<number> [--output=<file>]");
    console.error("\nOptions:");
    console.error("  --input=<file>       Input GeoJSON file (required)");
    console.error("  --tolerance=<number> Simplification tolerance (required)");
    console.error("                       Smaller = more detail, larger = more simplification");
    console.error("                       Typical range: 0.001 to 0.1");
    console.error("  --output=<file>      Output file (default: <input>-simplified.geojson)");
    console.error("  --high-quality       Use high-quality algorithm (default)");
    console.error("  --fast               Use faster algorithm");
    console.error("\nExamples:");
    console.error("  bun scripts/simplify-geojson.ts --input=world.geojson --tolerance=0.01");
    console.error("  bun scripts/simplify-geojson.ts --input=data.geojson --tolerance=0.05 --output=simple.geojson");
    process.exit(1);
  }

  try {
    await simplifyGeoJSON(options as SimplifyOptions);
  } catch (err) {
    console.error(`❌ Error: ${err}`);
    process.exit(1);
  }
}

export { simplifyGeoJSON };