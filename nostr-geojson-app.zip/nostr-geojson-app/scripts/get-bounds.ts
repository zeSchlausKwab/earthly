#!/usr/bin/env bun

/**
 * Fetch administrative boundaries from Nominatim OpenStreetMap API
 * Returns GeoJSON polygon data for places (cities, countries, regions, etc.)
 *
 * Usage: bun scripts/get-bounds.ts <place-name> [--output=<path>] [--format=geojson|svg|kml|text]
 *
 * Examples:
 *   bun scripts/get-bounds.ts "Berlin"
 *   bun scripts/get-bounds.ts "Vienna, Austria" --output=./vienna.geojson
 *   bun scripts/get-bounds.ts "New York City" --format=geojson
 */

import type { FeatureCollection, Feature, Polygon, MultiPolygon } from "geojson";

interface NominatimSearchResult {
  place_id: number;
  licence: string;
  osm_type: string;
  osm_id: number;
  lat: string;
  lon: string;
  display_name: string;
  class: string;
  type: string;
  importance: number;
  geojson?: {
    type: string;
    coordinates: any;
  };
}

interface GetBoundsOptions {
  placeName: string;
  output?: string;
  format?: "geojson" | "svg" | "kml" | "text";
  limit?: number;
}

async function getBounds(options: GetBoundsOptions): Promise<FeatureCollection> {
  const { placeName, format = "geojson", limit = 1 } = options;

  console.log(`🔍 Searching Nominatim for: "${placeName}"`);

  // Construct Nominatim API URL
  const params = new URLSearchParams({
    q: placeName,
    format: "json",
    polygon_geojson: "1", // Request GeoJSON polygon
    limit: String(limit),
  });

  const url = `https://nominatim.openstreetmap.org/search?${params}`;

  try {
    const response = await fetch(url, {
      headers: {
        "User-Agent": "Earthly-GeoJSON-App/1.0", // Required by Nominatim usage policy
      },
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    const results = (await response.json()) as NominatimSearchResult[];

    if (results.length === 0) {
      throw new Error(`No results found for "${placeName}"`);
    }

    console.log(`✅ Found ${results.length} result(s)`);

    // Convert to GeoJSON FeatureCollection
    const features: Feature[] = results
      .filter((result) => result.geojson) // Only include results with geometry
      .map((result, index) => {
        const geometry = result.geojson!;

        return {
          type: "Feature",
          id: `nominatim-${result.osm_type}-${result.osm_id}`,
          geometry: geometry as Polygon | MultiPolygon,
          properties: {
            place_id: result.place_id,
            osm_type: result.osm_type,
            osm_id: result.osm_id,
            display_name: result.display_name,
            class: result.class,
            type: result.type,
            importance: result.importance,
            lat: parseFloat(result.lat),
            lon: parseFloat(result.lon),
            source: "OpenStreetMap",
            source_url: `https://www.openstreetmap.org/${result.osm_type}/${result.osm_id}`,
            license: "ODbL", // OpenStreetMap license
            attribution: "© OpenStreetMap contributors",
          },
        };
      });

    if (features.length === 0) {
      throw new Error(`Results found but no polygon geometry available for "${placeName}"`);
    }

    const featureCollection: FeatureCollection = {
      type: "FeatureCollection",
      name: placeName,
      features,
    };

    // Report on primary result
    const primary = results[0];
    console.log(`\n📍 Primary result:`);
    console.log(`   Name: ${primary.display_name}`);
    console.log(`   Type: ${primary.class}/${primary.type}`);
    console.log(`   OSM: ${primary.osm_type}/${primary.osm_id}`);
    console.log(`   Center: ${primary.lat}, ${primary.lon}`);

    // Calculate size
    const jsonString = JSON.stringify(featureCollection);
    const size = new TextEncoder().encode(jsonString).length;
    console.log(`\n📦 GeoJSON size: ${(size / 1024).toFixed(2)} KB (${size} bytes)`);

    if (size > 1024 * 1024) {
      console.log(`⚠️  Size > 1MB - Consider using blob reference`);
    } else if (size > 800 * 1024) {
      console.log(`⚠️  Size approaching 1MB - May need simplification`);
    } else {
      console.log(`✅ Size OK for inline use`);
    }

    // Save to file if output specified
    if (options.output) {
      await Bun.write(options.output, jsonString);
      console.log(`\n💾 Saved to: ${options.output}`);
    }

    return featureCollection;
  } catch (err) {
    console.error(`❌ Error fetching from Nominatim: ${err}`);
    throw err;
  }
}

// CLI entry point
if (import.meta.main) {
  const args = process.argv.slice(2);

  if (args.length === 0 || args[0].startsWith("--")) {
    console.error("Usage: bun get-bounds.ts <place-name> [--output=<path>] [--limit=<n>]");
    console.error("\nExamples:");
    console.error('  bun scripts/get-bounds.ts "Berlin"');
    console.error('  bun scripts/get-bounds.ts "Vienna, Austria" --output=./vienna.geojson');
    console.error('  bun scripts/get-bounds.ts "New York City" --limit=3');
    console.error("\nNotes:");
    console.error("  - Uses OpenStreetMap Nominatim API");
    console.error("  - Respects Nominatim usage policy (max 1 request/second)");
    console.error("  - Returns GeoJSON with ODbL license");
    console.error("  - See: https://nominatim.org/release-docs/develop/api/Search/");
    process.exit(1);
  }

  const placeName = args[0];
  const options: GetBoundsOptions = { placeName };

  for (const arg of args.slice(1)) {
    if (arg.startsWith("--output=")) {
      options.output = arg.split("=")[1];
    } else if (arg.startsWith("--limit=")) {
      options.limit = parseInt(arg.split("=")[1], 10);
    } else if (arg.startsWith("--format=")) {
      options.format = arg.split("=")[1] as any;
    }
  }

  try {
    await getBounds(options);
    process.exit(0);
  } catch (err) {
    process.exit(1);
  }
}

export { getBounds };