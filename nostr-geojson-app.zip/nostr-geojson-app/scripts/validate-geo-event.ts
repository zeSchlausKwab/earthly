#!/usr/bin/env bun

/**
 * Validates a GeoJSON Nostr event against the spec
 * Usage: bun scripts/validate-geo-event.ts <event-json-file-or-string>
 */

import type { NostrEvent } from "@nostr-dev-kit/ndk";
import type { FeatureCollection } from "geojson";

interface ValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

/**
 * Validate a kind 31991 GeoJSON Data Event
 */
function validateGeoDataEvent(event: NostrEvent): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Check kind
  if (event.kind !== 31991) {
    errors.push(`Expected kind 31991, got ${event.kind}`);
  }

  // Check mandatory tags
  const dTag = event.tags.find(tag => tag[0] === "d");
  if (!dTag || !dTag[1]) {
    errors.push("Missing mandatory 'd' tag (dataset identifier)");
  }

  const bboxTag = event.tags.find(tag => tag[0] === "bbox");
  if (!bboxTag || !bboxTag[1]) {
    errors.push("Missing mandatory 'bbox' tag");
  } else {
    const parts = bboxTag[1].split(",").map(s => parseFloat(s.trim()));
    if (parts.length !== 4 || parts.some(n => isNaN(n))) {
      errors.push("Invalid bbox format. Expected: west,south,east,north");
    }
  }

  // Check content is valid GeoJSON
  if (!event.content) {
    errors.push("Missing content (GeoJSON FeatureCollection)");
  } else {
    try {
      const geojson = JSON.parse(event.content) as FeatureCollection;
      if (geojson.type !== "FeatureCollection") {
        errors.push(`Invalid GeoJSON: expected FeatureCollection, got ${geojson.type}`);
      }
      if (!Array.isArray(geojson.features)) {
        errors.push("Invalid GeoJSON: features must be an array");
      }
    } catch (err) {
      errors.push(`Failed to parse content as JSON: ${err}`);
    }
  }

  // Check recommended tags
  if (!event.tags.find(tag => tag[0] === "g")) {
    warnings.push("Missing recommended 'g' tag (geohash)");
  }

  if (!event.tags.find(tag => tag[0] === "checksum")) {
    warnings.push("Missing recommended 'checksum' tag");
  }

  if (!event.tags.find(tag => tag[0] === "size")) {
    warnings.push("Missing recommended 'size' tag");
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

/**
 * Validate a kind 30406 GeoJSON Collection Event
 */
function validateGeoCollectionEvent(event: NostrEvent): ValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  // Check kind
  if (event.kind !== 30406) {
    errors.push(`Expected kind 30406, got ${event.kind}`);
  }

  // Check mandatory tags
  const dTag = event.tags.find(tag => tag[0] === "d");
  if (!dTag || !dTag[1]) {
    errors.push("Missing mandatory 'd' tag (collection identifier)");
  }

  // Check for dataset references
  const aTags = event.tags.filter(tag => tag[0] === "a");
  if (aTags.length === 0) {
    warnings.push("No 'a' tags found (dataset references)");
  }

  // Validate content is valid JSON metadata
  if (!event.content) {
    errors.push("Missing content (collection metadata)");
  } else {
    try {
      const metadata = JSON.parse(event.content);
      if (typeof metadata !== "object") {
        errors.push("Content must be a JSON object");
      }
    } catch (err) {
      errors.push(`Failed to parse content as JSON: ${err}`);
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

/**
 * Main validation dispatcher
 */
function validateEvent(event: NostrEvent): ValidationResult {
  if (event.kind === 31991) {
    return validateGeoDataEvent(event);
  } else if (event.kind === 30406) {
    return validateGeoCollectionEvent(event);
  } else {
    return {
      valid: false,
      errors: [`Unsupported event kind: ${event.kind}. Expected 31991 or 30406.`],
      warnings: [],
    };
  }
}

// CLI entry point
if (import.meta.main) {
  const input = process.argv[2];

  if (!input) {
    console.error("Usage: bun validate-geo-event.ts <event-json-file-or-string>");
    process.exit(1);
  }

  let event: NostrEvent;

  try {
    // Try parsing as JSON string first
    event = JSON.parse(input);
  } catch {
    // Try reading as file
    try {
      const file = Bun.file(input);
      const text = await file.text();
      event = JSON.parse(text);
    } catch (err) {
      console.error(`Failed to parse input: ${err}`);
      process.exit(1);
    }
  }

  const result = validateEvent(event);

  console.log("Validation Result:");
  console.log(`Valid: ${result.valid ? "✅ YES" : "❌ NO"}`);

  if (result.errors.length > 0) {
    console.log("\nErrors:");
    result.errors.forEach(err => console.log(`  ❌ ${err}`));
  }

  if (result.warnings.length > 0) {
    console.log("\nWarnings:");
    result.warnings.forEach(warn => console.log(`  ⚠️  ${warn}`));
  }

  process.exit(result.valid ? 0 : 1);
}

export { validateEvent, validateGeoDataEvent, validateGeoCollectionEvent };