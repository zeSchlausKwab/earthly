import { NDKEvent, registerEventClass, type NDKSigner } from "@nostr-dev-kit/ndk";

/**
 * TEMPLATE: Custom NDK Event Class
 * Replace TEMPLATE_NAME, TEMPLATE_KIND, and implement your domain logic
 */
export class TEMPLATE_NAMEEvent extends NDKEvent {
  static kinds = [TEMPLATE_KIND];

  static from(event: NDKEvent): TEMPLATE_NAMEEvent {
    const wrapped = new TEMPLATE_NAMEEvent(event.ndk, event);
    wrapped.kind = event.kind ?? TEMPLATE_NAMEEvent.kinds[0];
    return wrapped;
  }

  /**
   * Parsed content accessor
   */
  get parsedContent(): any {
    if (!this.content) return {};
    try {
      return JSON.parse(this.content);
    } catch {
      return {};
    }
  }

  set parsedContent(value: any) {
    this.content = JSON.stringify(value);
  }

  /**
   * Unique identifier (d tag)
   */
  get identifier(): string | undefined {
    return this.dTag;
  }

  set identifier(value: string | undefined) {
    this.dTag = value;
  }

  /**
   * Example tag accessor
   */
  get exampleTag(): string | undefined {
    return this.tagValue("example");
  }

  set exampleTag(value: string | undefined) {
    this.replaceOptionalTag("example", value);
  }

  /**
   * Ensures event has a d tag. Generates UUID if missing.
   */
  ensureIdentifier(): string {
    if (!this.identifier) {
      this.identifier = crypto.randomUUID();
    }
    return this.identifier;
  }

  /**
   * Helper to replace optional tags
   */
  private replaceOptionalTag(tagName: string, value: string | undefined) {
    this.removeTag(tagName);
    if (value !== undefined) {
      this.tags.push([tagName, value]);
    }
  }

  /**
   * Prepare event for publishing
   */
  private async prepareForPublish(signer?: NDKSigner): Promise<void> {
    this.kind = TEMPLATE_NAMEEvent.kinds[0];
    this.ensureIdentifier();
    // TODO: Add any derived metadata computation here
    await this.sign(signer);
  }

  /**
   * Publish new event
   */
  async publishNew(signer?: NDKSigner): Promise<TEMPLATE_NAMEEvent> {
    await this.prepareForPublish(signer);
    await this.publish();
    return this;
  }

  /**
   * Publish update to existing event
   */
  async publishUpdate(
    previous: TEMPLATE_NAMEEvent,
    signer?: NDKSigner
  ): Promise<TEMPLATE_NAMEEvent> {
    this.identifier = previous.identifier ?? previous.id;
    if (!this.identifier) {
      throw new Error("Identifier is required for updates.");
    }

    // Reference previous event
    this.removeTag("p");
    this.tags.push(["p", previous.id]);

    await this.prepareForPublish(signer);
    await this.publish();
    return this;
  }

  /**
   * Delete event (kind 5)
   */
  static async deleteEvent(
    ndk: NDK,
    event: TEMPLATE_NAMEEvent,
    reason?: string,
    signer?: NDKSigner
  ): Promise<void> {
    const identifier = event.identifier ?? event.dTag;
    if (!identifier) {
      throw new Error("Event is missing a d tag and cannot be deleted.");
    }

    const deletion = new NDKEvent(ndk);
    deletion.kind = 5; // NDKKind.EventDeletion
    deletion.content = reason ?? "";
    deletion.tags.push(["a", `${event.kind}:${event.pubkey}:${identifier}`]);
    if (event.id) {
      deletion.tags.push(["e", event.id]);
    }

    await deletion.sign(signer);
    await deletion.publish();
  }
}

registerEventClass(TEMPLATE_NAMEEvent);