# Public GeoJSON Datasets

This document catalogs curated public GeoJSON datasets useful for seeding Earthly with real-world geographic data.

## Size Guidelines

- **< 1MB**: Include directly in event content (inline FeatureCollection)
- **> 1MB**: Use blob references with external URL
- **1MB threshold**: ~1,048,576 bytes (rough guideline based on WebSocket limits and performance)

## Decision Factors for Inline vs Blob

1. **Size**: Primary factor - content must fit within relay WebSocket message limits
2. **Performance**: Large inline content slows down event propagation
3. **Simplicity**: Smaller datasets are easier to work with inline
4. **Caching**: Blob references allow CDN caching for frequently accessed data

## Strategies for Large Datasets

1. **Split by region**: Break world data into continents/countries
2. **Simplify geometry**: Use `turf.simplify()` to reduce vertex count
3. **Create collections**: Use kind 30406 to group related datasets
4. **Multi-resolution**: Provide both simplified inline + detailed blob versions

## Curated Public Datasets

### World Geographic Boundaries

**Source:** https://github.com/georgique/world-geojson

Comprehensive world geographic data organized by type:

#### Areas
- **URL:** https://github.com/georgique/world-geojson/tree/develop/areas
- **Content:** Administrative areas, regions
- **Size:** Varies (most < 500KB)
- **Use case:** Regional boundaries, administrative divisions
- **License:** Check repository

#### Countries
- **URL:** https://github.com/georgique/world-geojson/tree/develop/countries
- **Content:** Country boundaries
- **Size:** Individual countries typically < 1MB, world dataset > 5MB
- **Use case:** Country-level mapping, geopolitical boundaries
- **Recommended:** Split into individual country events or use blob reference for world dataset

#### States/Provinces
- **URL:** https://github.com/georgique/world-geojson/tree/develop/states
- **Content:** State/province boundaries by country
- **Size:** Varies by country
- **Use case:** Sub-national administrative boundaries

#### Country Codes
- **URL:** https://github.com/georgique/world-geojson/blob/develop/helper/countryCode.json
- **Content:** Country metadata with ISO codes
- **Size:** < 50KB
- **Use case:** Metadata enrichment, linking datasets

### United States GeoJSON

**Source:** https://eric.clst.org/tech/usgeojson/

High-quality US geographic data:

- **Content:** US states, counties, congressional districts, ZIP codes
- **Size:** Varies (states < 500KB, counties can be > 2MB)
- **Use case:** US-specific mapping, demographic analysis
- **Quality:** Well-maintained, regularly updated
- **Recommended:** Use state-level inline, county-level with blob references

### US Government Open Data

**Source:** https://catalog.data.gov/dataset/?res_format=GeoJSON

Massive catalog of government GeoJSON datasets:

- **Content:** Infrastructure, environmental, demographic, transportation
- **Size:** Highly variable (KB to GB)
- **Use case:** Specialized datasets (parks, infrastructure, protected areas)
- **License:** Public domain (US Government)
- **Note:** Requires manual curation - thousands of datasets available

### Natural Earth Countries

**Source:** https://github.com/datasets/geo-countries/blob/main/data/countries.geojson

Clean, simplified world country boundaries:

- **URL:** https://raw.githubusercontent.com/datasets/geo-countries/main/data/countries.geojson
- **Content:** Simplified country polygons with ISO codes
- **Size:** ~950KB (borderline - recommend inline or light simplification)
- **Use case:** World maps, country selection, minimal detail boundaries
- **License:** Open Data Commons Public Domain Dedication and License (PDDL)
- **Quality:** Excellent for web display, good balance of detail/size

### Historical Basemaps

**Source:** https://github.com/aourednik/historical-basemaps/tree/master/geojson

Historical political boundaries over time:

- **URL:** https://github.com/aourednik/historical-basemaps/tree/master/geojson
- **Content:** Political boundaries from different historical periods
- **Size:** Varies by time period and region
- **Use case:** Historical mapping, temporal datasets, educational
- **License:** Check repository
- **Special:** Include temporal tags (`["time", "1914"]`) for historical context

### OGC API Features Demo

**Source:** https://demo.ldproxy.net/cshapes/collections/boundary/items

Live OGC API with dynamic GeoJSON:

- **URL:** https://demo.ldproxy.net/cshapes/collections/boundary/items
- **Content:** Political boundaries with temporal data
- **Size:** API returns paginated results
- **Use case:** Testing API integration, dynamic data fetching
- **Format:** OGC API Features standard (modern GeoJSON API)
- **Note:** Requires API client, supports filters and pagination

## On-Demand Boundary Fetching with Nominatim

**Nominatim** is OpenStreetMap's geocoding service that provides administrative boundaries on-demand.

**Source:** https://nominatim.org/release-docs/develop/api/Search/#polygon-output

Use the `get-bounds.ts` script to fetch boundaries for any place:

```bash
# Fetch city boundary
bun .claude/skills/nostr-geojson-app/scripts/get-bounds.ts "Berlin"

# Fetch and save to file
bun scripts/get-bounds.ts "Vienna, Austria" --output=./vienna.geojson

# Get multiple results
bun scripts/get-bounds.ts "Springfield" --limit=3
```

**Features:**
- Returns GeoJSON Polygon or MultiPolygon
- Includes OSM metadata (place_id, osm_type, osm_id)
- Auto-calculates size and provides inline/blob recommendation
- Respects Nominatim usage policy (max 1 req/sec)
- License: ODbL (OpenStreetMap Open Database License)

**What you can fetch:**
- Cities: "Berlin", "New York City", "Tokyo"
- Countries: "Germany", "United States", "Japan"
- Regions: "Bavaria", "California", "Île-de-France"
- Districts: "Manhattan", "Brooklyn"
- Neighborhoods: "Kreuzberg, Berlin"
- Any administrative boundary in OpenStreetMap

**Tip:** More specific queries work better:
- ✅ "Vienna, Austria" (specific)
- ⚠️ "Vienna" (may return Virginia, USA)

## Recommended Workflow

### 1. Fetch and Analyze

**Option A: Fetch from static URL**
```bash
# Fetch remote GeoJSON
bun .claude/skills/nostr-geojson-app/scripts/fetch-geojson.ts \
  --url="https://example.com/data.geojson" \
  --output="./data.geojson"

# Check size and decide strategy
bun .claude/skills/nostr-geojson-app/scripts/json-size.ts ./data.geojson
```

**Option B: Fetch from Nominatim (on-demand)**
```bash
# Get boundary for a place
bun .claude/skills/nostr-geojson-app/scripts/get-bounds.ts "Berlin" --output=./berlin.geojson

# Size check is automatic, but you can also run:
bun .claude/skills/nostr-geojson-app/scripts/json-size.ts ./berlin.geojson
```

### 2. Process Based on Size

**If < 1MB (inline):**
```typescript
import { NDKGeoEvent } from "./src/lib/ndk/NDKGeoEvent";
const collection = JSON.parse(await Bun.file("./data.geojson").text());
const event = new NDKGeoEvent(ndk);
event.featureCollection = collection;
event.hashtags = ["countries", "world"];
await event.publishNew(signer);
```

**If > 1MB (blob reference):**
```typescript
// 1. Upload to blob storage (IPFS, Arweave, or HTTPS CDN)
const blobUrl = await uploadToBlobStorage(data);

// 2. Create stub event with blob reference
const event = new NDKGeoEvent(ndk);
event.featureCollection = {
  type: "FeatureCollection",
  name: "World Countries (Full Detail)",
  features: [] // Empty or include simplified preview features
};
event.blobReferences = [{
  scope: "collection",
  url: blobUrl,
  size: dataSize,
  sha256: await computeSha256(data),
  mimeType: "application/geo+json"
}];
await event.publishNew(signer);
```

**If 800KB - 1.2MB (borderline):**
```bash
# Simplify geometry to reduce size
bun .claude/skills/nostr-geojson-app/scripts/simplify-geojson.ts \
  --input="./data.geojson" \
  --tolerance=0.01 \
  --output="./data-simplified.geojson"
```

### 3. Add Attribution

Always include source and license tags:

```typescript
event.tags.push(["source", "https://github.com/datasets/geo-countries"]);
event.tags.push(["license", "PDDL"]);
event.tags.push(["attribution", "Natural Earth"]);
```

## Dataset Recommendations by Use Case

### World Overview Maps
- **Natural Earth Countries** - Best balance of size/detail
- Strategy: Inline (with light simplification if needed)

### Country Deep-Dives
- **georgique/world-geojson countries** - Detailed country boundaries
- Strategy: One event per country, inline

### US Mapping
- **eric.clst.org states** - State boundaries inline
- **eric.clst.org counties** - County boundaries via blob reference
- Strategy: Collection event grouping states + counties

### Historical Analysis
- **historical-basemaps** - Temporal boundaries
- Strategy: One event per time period, include temporal tags

### Infrastructure/Specialized
- **data.gov catalog** - Manually curate specific datasets
- Strategy: Varies - evaluate per dataset

## Size Estimation Examples

| Dataset | Approx Size | Strategy |
|---------|------------|----------|
| Single US state | 50-200 KB | Inline |
| All US states | ~2 MB | Blob or split by state |
| Single country (medium) | 100-500 KB | Inline |
| World countries (simplified) | ~950 KB | Inline (borderline) |
| World countries (full detail) | 5-10 MB | Blob reference |
| US counties (all) | 10+ MB | Blob reference |
| Historical period boundaries | 500KB - 2MB | Depends on period |

## Best Practices

1. **Always check size first** - Use `json-size.ts` before deciding strategy
2. **Include metadata** - Source, license, attribution tags are mandatory
3. **Test on relay** - Some relays have stricter limits than 1MB
4. **Use checksums** - Always include SHA-256 for blob references
5. **Simplify when possible** - Reduce vertices for web display using turf.simplify
6. **Version datasets** - Use `v` tag when updating with new data sources
7. **Geographic indexing** - Always compute bbox and geohash for discovery
8. **Collection organization** - Group related datasets (e.g., "US States 2024")
9. **Nominatim rate limits** - Respect max 1 request/second usage policy
10. **Check in test data** - Save Nominatim results to codebase for seeding and tests

## Nominatim Best Practices

When using `get-bounds.ts`:

1. **Be specific** - "Berlin, Germany" instead of just "Berlin"
2. **Use --limit** - Get multiple results to pick the right one
3. **Save results** - Check files into repo for consistent test data
4. **Batch fetching** - Add 1 second delay between requests
5. **Attribution** - Always include OSM attribution in events

Example batch fetch with delays:
```bash
for city in "Berlin" "Vienna" "Paris"; do
  bun scripts/get-bounds.ts "$city, Europe" --output="./seed-data/${city}.geojson"
  sleep 1  # Respect rate limit
done
```
