# NDK Custom Event Class Registration Pattern

This document describes the pattern for creating custom NDK event classes, as demonstrated in the NDKGeoEvent and NDKGeoCollectionEvent implementations.

## Overview

NDK (Nostr Development Kit) allows registering custom event classes that extend `NDKEvent` to provide type-safe, domain-specific functionality. This pattern is used extensively in the GeoJSON Nostr app for handling specialized event kinds.

## Core Pattern

### 1. Event Class Structure

```typescript
import { NDKEvent, registerEventClass, type NDKSigner } from "@nostr-dev-kit/ndk";

export class CustomEvent extends NDKEvent {
  // 1. Define supported kinds
  static kinds = [31991];

  // 2. Factory method for wrapping existing events
  static from(event: NDKEvent): CustomEvent {
    const wrapped = new CustomEvent(event.ndk, event);
    wrapped.kind = event.kind ?? CustomEvent.kinds[0];
    return wrapped;
  }

  // 3. Typed accessors for content
  get parsedContent(): SomeType {
    if (!this.content) return DEFAULT_VALUE;
    try {
      return JSON.parse(this.content) as SomeType;
    } catch {
      return DEFAULT_VALUE;
    }
  }

  set parsedContent(value: SomeType) {
    this.content = JSON.stringify(value);
  }

  // 4. Tag accessors with getters/setters
  get someTag(): string | undefined {
    return this.tagValue("someTag");
  }

  set someTag(value: string | undefined) {
    this.replaceOptionalTag("someTag", value);
  }

  // 5. Helper methods
  private replaceOptionalTag(tagName: string, value: string | undefined) {
    this.removeTag(tagName);
    if (value !== undefined) {
      this.tags.push([tagName, value]);
    }
  }

  // 6. Publishing methods
  async publishNew(signer?: NDKSigner): Promise<CustomEvent> {
    await this.prepareForPublish(signer);
    await this.publish();
    return this;
  }

  private async prepareForPublish(signer?: NDKSigner): Promise<void> {
    this.kind = CustomEvent.kinds[0];
    // ... set required tags, compute derived metadata, etc.
    await this.sign(signer);
  }
}

// 7. Register the event class
registerEventClass(CustomEvent);
```

## Key Components

### Static Properties

- **`kinds`**: Array of event kinds this class handles
- **`from(event)`**: Factory method to wrap existing NDKEvent instances

### Content Management

- Use getters/setters for typed access to JSON-serialized content
- Always provide safe defaults for missing/invalid content
- Handle parsing errors gracefully

### Tag Management

- Create getters/setters for each tag type in your spec
- Use helper methods like `replaceOptionalTag()` for consistent tag updates
- Handle array tags (multiple values) appropriately

### Publishing Workflow

```typescript
// Pattern: separate preparation from publishing
private async prepareForPublish(signer?: NDKSigner): Promise<void> {
  this.kind = CustomEvent.kinds[0];
  // 1. Ensure required fields (e.g., d tag with UUID)
  // 2. Compute derived metadata (e.g., bbox, checksum)
  // 3. Sign the event
  await this.sign(signer);
}

async publishNew(signer?: NDKSigner): Promise<CustomEvent> {
  await this.prepareForPublish(signer);
  await this.publish();
  return this;
}

async publishUpdate(previous: CustomEvent, signer?: NDKSigner): Promise<CustomEvent> {
  // Preserve identifiers from previous version
  this.datasetId = previous.datasetId ?? previous.id;
  // Increment version
  // Reference previous event with p tag
  await this.prepareForPublish(signer);
  await this.publish();
  return this;
}
```

### Deletion Pattern

```typescript
static async deleteDataset(
  ndk: NDK,
  dataset: CustomEvent,
  reason?: string,
  signer?: NDKSigner
): Promise<void> {
  const datasetId = dataset.datasetId ?? dataset.dTag;
  if (!datasetId) throw new Error("Missing d tag");

  const deletion = new NDKEvent(ndk);
  deletion.kind = NDKKind.EventDeletion; // kind 5
  deletion.content = reason ?? "";
  // Reference by coordinate (a tag) and event id (e tag)
  deletion.tags.push(["a", `${dataset.kind}:${dataset.pubkey}:${datasetId}`]);
  if (dataset.id) {
    deletion.tags.push(["e", dataset.id]);
  }

  await deletion.sign(signer);
  await deletion.publish();
}
```

## Registration

Always register your custom event class at the module level:

```typescript
registerEventClass(CustomEvent);
```

This ensures NDK uses your custom class when fetching events of the specified kinds.

## Real-World Examples

### NDKGeoEvent (kind 31991)

- Wraps RFC 7946 GeoJSON FeatureCollection
- Provides typed accessors for: bbox, geohash, CRS, checksum, size, version, blob references
- Auto-computes derived metadata (bbox from geometry, geohash from centroid, checksum)
- Handles external blob references for large datasets

### NDKGeoCollectionEvent (kind 30406)

- Wraps collection metadata (name, description, license, etc.)
- References multiple GeoJSON data events via `a` tags
- Combines bbox from all member datasets

## Best Practices

1. **Type Safety**: Always provide TypeScript types for parsed content and tag values
2. **Safe Defaults**: Handle missing/invalid data gracefully with sensible defaults
3. **Encapsulation**: Use private helpers for internal operations
4. **Convenience**: Provide high-level methods (publishNew, publishUpdate) that handle the full workflow
5. **Validation**: Validate data before publishing (checksums, required fields, etc.)
6. **Immutability**: Remember that Nostr events are immutable - updates create new events
7. **References**: Use proper tag conventions (a tags for coordinates, e tags for event IDs, p tags for parents)

## Integration with React Hooks

When using `@nostr-dev-kit/react`, custom event classes work seamlessly with hooks:

```typescript
import { useSubscribe } from "@nostr-dev-kit/react";
import { NDKGeoEvent } from "./NDKGeoEvent";

function MyComponent() {
  const { events } = useSubscribe({
    filters: [{ kinds: [31991], "#g": ["u2yh7"] }],
  });

  // Events are automatically instances of NDKGeoEvent
  const geoEvents = events as NDKGeoEvent[];

  return (
    <>
      {geoEvents.map(event => (
        <div key={event.id}>
          {event.featureCollection.name}
          Bbox: {event.boundingBox?.join(", ")}
        </div>
      ))}
    </>
  );
}
```

## Common Patterns

### Computed Metadata

```typescript
updateDerivedMetadata(): void {
  const collection = this.featureCollection;

  // Compute bbox using turf
  const computedBbox = turf.bbox(collection);
  this.boundingBox = computedBbox as GeoBoundingBox;

  // Compute geohash from centroid
  const centroid = turf.centroid(collection);
  this.geohash = encodeGeohash(
    centroid.geometry.coordinates[1],
    centroid.geometry.coordinates[0],
    6
  );

  // Compute size
  this.datasetSize = new TextEncoder().encode(this.content).length;
}
```

### Checksum Generation

```typescript
async updateChecksum(): Promise<void> {
  const encoder = new TextEncoder();
  const data = encoder.encode(this.content ?? "");
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = Array.from(new Uint8Array(hashBuffer));
  this.checksum = hashArray
    .map(byte => byte.toString(16).padStart(2, "0"))
    .join("");
}
```

### Versioning

```typescript
async publishUpdate(previous: CustomEvent, signer?: NDKSigner): Promise<CustomEvent> {
  // Preserve dataset ID
  this.datasetId = previous.datasetId ?? previous.id;

  // Increment version
  const previousVersion = Number(previous.version);
  if (!Number.isNaN(previousVersion)) {
    this.version = String(previousVersion + 1);
  }

  // Reference previous event
  this.removeTag("p");
  this.tags.push(["p", previous.id]);

  await this.prepareForPublish(signer);
  await this.publish();
  return this;
}
```